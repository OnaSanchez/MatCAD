
public interface Observer(){

      public __init__(this, observer);
      public update(this, observer, nom_observable, event);
      public __str__(this);
}
