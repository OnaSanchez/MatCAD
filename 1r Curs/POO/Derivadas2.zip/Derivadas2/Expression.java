
public interface Expression{
    DualNumber evaluate(DualNumber dn); //Si no funciona aquí poner public
    //Esto decidirá si evaluamos la u (valor de la funcion) o la uprime (su derivada)
}

